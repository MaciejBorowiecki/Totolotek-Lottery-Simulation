package totolotek;

// Klasa odpowiadająca za przechowywanie globalnie dostępnych stałych, aby uniknąć magicznych liczb;
public class Stałe {
    public final static int wszystkieNumeryZakładu = 49;
    public final static int poprawnaIlośćZaznaczonych = 6;
    public final static int maxIlośćZakładówNaBlankiecie = 8;
    public final static int maxilośćLosowańNaBlankiecie = 10;
}
