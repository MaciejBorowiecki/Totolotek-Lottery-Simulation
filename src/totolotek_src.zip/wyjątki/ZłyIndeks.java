package wyjątki;

public class ZłyIndeks extends Exception{
    public ZłyIndeks(String message) {
        super(message);
    }
}
